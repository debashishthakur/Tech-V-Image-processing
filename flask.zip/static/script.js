const edgeSlider = document.getElementById("edgeSlider")
const blurSlider = document.getElementById("blurSlider")
const sliderBar = document.getElementById("SliderOption")

const showSlider1 = () => {
    //  sliderBar.classList.toggle("hidden")
    console.log(1)
}

const showSlider2 = () => {
    blurSlider.classList.toggle("hidden")

 }